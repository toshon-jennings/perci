import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, resolve, sep } from 'node:path';
import { fileURLToPath } from 'node:url';
import { isTrustedLoopbackRequest, ocrCookieMatches, tokenMatches } from './server-auth.mjs';
import packageJson from './package.json' with { type: 'json' };

const HOST = '127.0.0.1';
const PORT = process.env.NODE_ENV === 'test' ? Number(process.env.KEYSAFE_TEST_PORT || 0) : 4100;
const token = process.env.KEYSAFE_SERVER_TOKEN || '';
const nonce = process.env.KEYSAFE_SERVER_NONCE || '';
const root = resolve(fileURLToPath(new URL('./dist', import.meta.url)));
const ocrAsset = /^\/ocr\/(?:worker\.min\.js|tesseract-core-lstm\.wasm(?:\.js)?|eng\.traineddata\.gz)$/;

if (token.length < 32 || nonce.length < 16) {
  throw new Error('KEYSAFE_SERVER_TOKEN and KEYSAFE_SERVER_NONCE are required.');
}
if (!existsSync(root)) throw new Error('KeySafe dist/ is missing. Run npm run build first.');

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.gz': 'application/gzip',
  '.html': 'text/html; charset=utf-8',
  '.jpeg': 'image/jpeg',
  '.jpg': 'image/jpeg',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.svg': 'image/svg+xml',
  '.wasm': 'application/wasm',
  '.woff2': 'font/woff2',
};

function applyHeaders(response) {
  response.setHeader('Cache-Control', 'no-store');
  response.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' 'wasm-unsafe-eval'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com; img-src 'self' blob: data:; connect-src 'self' blob: http://127.0.0.1:* http://localhost:* https://generativelanguage.googleapis.com https://api.openai.com https://api.anthropic.com https://openrouter.ai; object-src 'none'; base-uri 'none'; frame-ancestors 'self'");
  response.setHeader('Cross-Origin-Resource-Policy', 'same-origin');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'SAMEORIGIN');
}

function reject(response, status) {
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8' });
  response.end(JSON.stringify({ error: status === 401 ? 'unauthorized' : 'invalid request' }));
}

const server = createServer((request, response) => {
  applyHeaders(response);
  if (!isTrustedLoopbackRequest({
    host: request.headers.host,
    origin: request.headers.origin,
    fetchSite: request.headers['sec-fetch-site'],
    expectedHost: `${HOST}:${server.address()?.port || PORT}`,
  })) {
    reject(response, 400);
    return;
  }
  let requestUrl;
  try {
    requestUrl = new URL(request.url || '/', `http://${HOST}:${PORT}`);
  } catch {
    reject(response, 400);
    return;
  }
  const authorizedHeader = tokenMatches(token, request.headers.authorization);
  if (!authorizedHeader && !(ocrAsset.test(requestUrl.pathname) && ocrCookieMatches(token, request.headers.cookie))) {
    reject(response, 401);
    return;
  }
  if (authorizedHeader) response.setHeader('Set-Cookie', `keysafe_ocr=${token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=1800`);

  if (requestUrl.pathname === '/api/health') {
    response.writeHead(200, { 'Content-Type': 'application/json; charset=utf-8' });
    response.end(JSON.stringify({ productId: 'keysafe', version: packageJson.version, nonce }));
    return;
  }
  if (request.method !== 'GET' && request.method !== 'HEAD') {
    reject(response, 405);
    return;
  }

  let pathname;
  try {
    pathname = decodeURIComponent(requestUrl.pathname);
  } catch {
    reject(response, 400);
    return;
  }
  const candidate = resolve(root, `.${pathname}`);
  if (candidate !== root && !candidate.startsWith(`${root}${sep}`)) {
    reject(response, 400);
    return;
  }
  const filePath = existsSync(candidate) && statSync(candidate).isFile() ? candidate : resolve(root, 'index.html');
  response.writeHead(200, { 'Content-Type': contentTypes[extname(filePath)] || 'application/octet-stream' });
  if (request.method === 'HEAD') response.end();
  else createReadStream(filePath).pipe(response);
});

server.listen(PORT, HOST, () => {
  process.stdout.write(`KeySafe production server listening on http://${HOST}:${server.address().port}\n`);
});

// Perci launches the production server with an IPC channel. If Perci exits,
// close gracefully so a stale token cannot occupy the port on the next launch.
if (typeof process.send === 'function') {
  process.channel?.unref?.();
  process.once('disconnect', () => server.close());
}
