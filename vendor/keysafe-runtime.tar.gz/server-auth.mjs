import { timingSafeEqual } from 'node:crypto';

export function tokenMatches(expected, authorization) {
  if (typeof expected !== 'string' || expected.length < 32) return false;
  if (typeof authorization !== 'string' || !authorization.startsWith('Bearer ')) return false;
  const actual = authorization.slice(7);
  const expectedBytes = Buffer.from(expected);
  const actualBytes = Buffer.from(actual);
  return expectedBytes.length === actualBytes.length && timingSafeEqual(expectedBytes, actualBytes);
}

export function ocrCookieMatches(expected, cookieHeader) {
  if (typeof cookieHeader !== 'string' || cookieHeader.length > 4096) return false;
  const cookie = cookieHeader.split(';').map(value => value.trim()).find(value => value.startsWith('keysafe_ocr='));
  return cookie ? tokenMatches(expected, `Bearer ${cookie.slice('keysafe_ocr='.length)}`) : false;
}

export function isTrustedLoopbackRequest({ host, origin, fetchSite, expectedHost = '127.0.0.1:4100' }) {
  if (host !== expectedHost) return false;
  if (origin && origin !== `http://${expectedHost}`) return false;
  return !fetchSite || fetchSite === 'same-origin' || fetchSite === 'none';
}
